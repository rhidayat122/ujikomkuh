
Allah Maha Melihat

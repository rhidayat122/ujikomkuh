<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class testing extends Model
{
    //
}

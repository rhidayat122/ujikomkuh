<?php

namespace App\Exceptions;

use Exception;

class BookException extends Exception {
    
}
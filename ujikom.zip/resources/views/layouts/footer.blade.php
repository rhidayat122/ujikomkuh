<center><div id="copyright text-right">© Copyright 2017 Penggajian Mamat</div></center>

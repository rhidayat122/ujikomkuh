<?php $__env->startSection('title'); ?>
List Motor
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Column -->
    <div class="col-sm-12">
        <div class="card">
            <div class="card-block">
                <h4 class="card-title">Ubah Data Motor</h4>
                <div class="text-right">
                
                </div>
                    <?php echo Form::model($motor, ['url' => route('motors.update', $motor->id), 'method' => 'put', 'class' => 'form-horizontal']); ?>

                    <?php echo $__env->make('motors._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo Form::close(); ?>

                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
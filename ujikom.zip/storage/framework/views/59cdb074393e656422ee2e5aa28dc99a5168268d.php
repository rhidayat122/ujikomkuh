<div class="form-group<?php echo e($errors->has('author_id') ? ' has-error': ''); ?>">
    <?php echo Form::label('id_merk', 'Merk', ['class' => 'col-md-2 control-label']); ?>

    <div class="col-md-4">
        <?php echo Form::select('id_merk', [''=>'']+App\Merk::pluck('merk', 'id')->all(), null, ['class' => 'js-selectize form-control', 'placeholder' => 'Pilih Merk']); ?>

        <?php echo $errors->first('id_merk', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group<?php echo e($errors->has('author_id') ? ' has-error': ''); ?>">
    <?php echo Form::label('id_kategori', 'Kategori', ['class' => 'col-md-2 control-label']); ?>

    <div class="col-md-4">
        <?php echo Form::select('id_kategori', [''=>'']+App\kategori::pluck('jenis', 'id')->all(), null, ['class' => 'js-selectize form-control', 'placeholder' => 'Pilih Kategori']); ?>

        <?php echo $errors->first('id_kategori', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group<?php echo e($errors->has('no_stnk') ? ' has-error': ''); ?>">
<?php echo Form::label('nama_motor', 'Nama Motor', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-4">
        <?php echo Form::text('nama_motor', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('nama_motor', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group<?php echo e($errors->has('tahun_keluar') ? ' has-error': ''); ?>">
<?php echo Form::label('tahun_keluar', 'Tahun Keluar', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-4">
        <?php echo Form::text('tahun_keluar', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('tahun_keluar', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group<?php echo e($errors->has('no_stnk') ? ' has-error': ''); ?>">
<?php echo Form::label('no_stnk', 'Nomor Stnk', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-4">
        <?php echo Form::text('no_stnk', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('no_stnk', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group<?php echo e($errors->has('harga_jual') ? ' has-error': ''); ?>">
<?php echo Form::label('mesin', 'Mesin', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-4">
        <?php echo Form::number('mesin', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('mesin', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group<?php echo e($errors->has('harga_beli') ? ' has-error': ''); ?>">
<?php echo Form::label('harga_beli', 'Harga Beli', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-4">
        <?php echo Form::number('harga_beli', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('harga_beli', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group<?php echo e($errors->has('harga_jual') ? ' has-error': ''); ?>">
<?php echo Form::label('harga_jual', 'Harga Jual', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-4">
        <?php echo Form::number('harga_jual', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('harga_jual', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group<?php echo e($errors->has('warna') ? ' has-error': ''); ?>">
<?php echo Form::label('warna', 'Warna', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-4">
        <?php echo Form::text('warna', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('warna', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group<?php echo e($errors->has('gambar') ? ' has-error': ''); ?>">
    <?php echo Form::label('gambar', 'Gambar', ['class' => 'col-md-2 control-label']); ?>

    <div class="col-md-4">
        <?php echo Form::file('gambar', null, ['class' => 'form-control']); ?>

        <?php if(isset($motor) && $motor->gambar): ?>
            <p>
                <?php echo Html::image(asset('img/'.$motor->gambar), null, ['class' => 'img-rounded img-responsive']); ?>

            </p>
        <?php endif; ?>
        <?php echo $errors->first('gambar', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-4 col-md-offset-2">
        <?php echo Form::submit('Simpan', ['class' => 'btn btn-primary']); ?>

    </div>
</div>

<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Bootstrap core CSS. Bootswatch: Lumen -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Font-Awesome -->
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">

    <!-- DataTable CSS -->
    <link href="<?php echo e(asset('css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Selectize -->
    <link href="<?php echo e(asset('css/selectize.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/selectize.bootstrap3.css')); ?>" rel="stylehsset">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>

        <style>
    body {
          background-image: url(<?php echo e(asset ('bg.jpg')); ?>);
          background-repeat: no-repeat;
          background-size: cover;
          background-attachment: fixed;

         }
    </style>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <span>
                            <!-- dark Logo text -->
                            <img src="<?php echo e(asset('/assets/images/logo-text.png')); ?>" alt="homepage" class="dark-logo" />
                        </span>
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        <?php if(Auth::check()): ?>
                            <?php echo Html::smartNav(url('/home'), 'Dashboard'); ?>

                        <?php endif; ?>

                        <?php if (app('laratrust')->hasRole('admin')) : ?>
                            <?php echo Html::smartNav(route('authors.index'), 'Penulis'); ?>

                            <?php echo Html::smartNav(route('books.index'), 'Buku'); ?>

                            <?php echo Html::smartNav(route('members.index'), 'Members'); ?>

                            <?php echo Html::smartNav(route('statistics.index'), 'Peminjaman'); ?>

                        <?php endif; // app('laratrust')->hasRole ?>
                        
                        <?php if (app('laratrust')->hasRole('member')) : ?>
                            <?php echo Html::smartNav(route('motors.index'), 'Motor'); ?>

                        <?php endif; // app('laratrust')->hasRole ?>
                        <?php if(auth()->check()): ?>
                            <?php echo Html::smartNav(url('/settings/profile'), 'Profile'); ?>

                        <?php endif; ?>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::check()): ?>
                        
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="<?php echo e(url('settings/password')); ?>"><i class="fa fa-btn fa-lock"></i> Ubah Password</a></li>
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <?php echo $__env->make('layouts._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>

        <footer class="row">
        <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </footer>

    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    
    <!-- DataTable JS -->
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap.min.js')); ?>"></script>

    <!-- Selectize -->
    <script src="<?php echo e(asset('js/selectize.min.js')); ?>"></script>

    <!-- Custom JS -->
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

    <!-- Scripts -->
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>

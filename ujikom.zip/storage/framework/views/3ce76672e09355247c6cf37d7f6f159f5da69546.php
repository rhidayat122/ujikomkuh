<?php $__env->startSection('title'); ?>
Transaksi Penjualan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Column -->
    <div class="col-sm-12">
        <div class="card">
            <div class="card-block">
                <h4 class="card-title">Transaksi Jual</h4>
                <div class="text-right">
                
                </div>
                    <?php echo Form::open(['url' => route('transaksijuals.store', $motor->id), 'method' => 'post','files' => 'true', 'enctype' => 'multipart/form-data', 'class' => 'form-horizontal']); ?>

                    <?php echo $__env->make('transaksijuals._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo Form::close(); ?>

                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
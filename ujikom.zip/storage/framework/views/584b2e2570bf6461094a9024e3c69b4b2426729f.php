<div class="form-group<?php echo e($errors->has('nama') ? ' has-error': ''); ?>">
    <?php echo Form::label('name', 'Nama', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-4">
        <?php echo Form::text('nama', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

	<div class="form-group<?php echo e($errors->has('jenis_kelamin') ? ' has-error': ''); ?>">
    <?php echo Form::label('name', 'Jenis Kelamin', ['class' => 'col-md-2 control-label']); ?>

		<div class="col-md-4">
			<input type="radio" name="jenis_kelamin" value="Laki-Laki" required=""><label>Laki-laki &nbsp;</label>
			<input type="radio" name="jenis_kelamin" value="Perempuan" required=""><label>Perempuan</label>
		</div>
	</div>

<div class="form-group<?php echo e($errors->has('alamat') ? ' has-error': ''); ?>">
    <?php echo Form::label('name', 'Alamat', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-4">
        <?php echo Form::text('alamat', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('alamat', '<p class="help-block">:message</p>'); ?>

    </div>
</div>


<div class="form-group<?php echo e($errors->has('no_hp') ? ' has-error': ''); ?>">
    <?php echo Form::label('name', 'Nomor HP', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-4">
        <?php echo Form::number('no_hp', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('no_hp', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group<?php echo e($errors->has('no_ktp') ? ' has-error': ''); ?>">
    <?php echo Form::label('name', 'Nomor KTP', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-4">
        <?php echo Form::number('no_ktp', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('no_ktp', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group<?php echo e($errors->has('status') ? ' has-error': ''); ?>">
    <?php echo Form::label('name', 'Status', ['class' => 'col-md-2 control-label']); ?>

		<div class="col-md-4">
			<input type="radio" name="status" value="Belum Nikah" required=""><label>Belum Nikah &nbsp;</label>
			<input type="radio" name="status" value="Nikah" required=""><label>Nikah</label>
		</div>
	</div>



<div class="form-group">
    <div class="col-md-4 col-md-offset-2">
        <?php echo Form::submit('Simpan', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <ul class="breadcrumb">
                <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                <li><a href="<?php echo e(url('/admin/members')); ?>">Member</a></li>
                <li class="active">Detail <?php echo e($member->name); ?></li>
            </ul>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h2 class="panel-title">Detail <?php echo e($member->name); ?></h2>
                </div>

                <div class="panel-body">
                    <p>Buku yang sedang dipinjam:</p>

                    <table class="table table-condensed table-striped">
                        <thead>
                            <tr>
                                <td>Judul</td>
                                <td>Tanggal Peminjaman</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $member->borrowLogs()->borrowed()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($log->book->title); ?></td>
                                    <td><?php echo e($log->created_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="2">Tidak ada data</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <p>Buku yang telah dikembalikan:</p>

                    <table class="table table-condensed table-striped">
                        <thead>
                            <tr>
                                <td>Judul</td>
                                <td>Tanggal Kembali</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $member->borrowLogs()->returned()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($log->book->title); ?></td>
                                    <td><?php echo e($log->updated_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="2">Tidak ada data</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
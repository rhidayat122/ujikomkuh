<p>
    Halo <?php echo e($member->name); ?>

</p>
<p>
    Admin kami telah mendaftarkan email Anda <?php echo e($member->email); ?> ke Larapus. Untuk login, silahkan kunjungi <a href="<?php echo e($login = url('login')); ?>"><?php echo e($login); ?></a> Login dengan email Anda dan password <strong><?php echo e($password); ?></strong>
</p>

<p>
    Jika Anda ingin mengubah password, silahkan kunjungi <a href="<?php echo e($reset = url('password/reset')); ?>"><?php echo e($reset); ?></a> dan masukan email Anda.
</p>